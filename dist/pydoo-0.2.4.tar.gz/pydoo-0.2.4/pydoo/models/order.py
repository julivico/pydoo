# -*- coding: utf-8 -*-


class Order(object):
    pass


class OrderLine(object):
    pass
